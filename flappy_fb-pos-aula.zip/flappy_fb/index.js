// configuracao básica de servidor
var express = require("express");
var app = express();
var servidor = require("http").createServer(app);
var bodyParser= require('body-parser');
var recordes = {};

// envia o que está na pasta public
app.use(express.static("public"));
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.post("/recorde", function(req, res) {
    var idJogador = req.body.id;
    var pontos = req.body.pontos;
    console.log(idJogador + " : " + pontos);
    if(recordes.hasOwnProperty(idJogador)){
        if(pontos >= recordes[idJogador]){
            recordes[idJogador] = pontos;
        }
    }
    else {
         recordes[idJogador] = pontos;
    }
    res.send({pontos: recordes[idJogador]});
});

servidor.listen(3000, function(){
    console.log("RODANDO!");
});