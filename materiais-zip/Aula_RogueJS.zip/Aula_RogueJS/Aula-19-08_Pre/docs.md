## Rogue!

Jogo estilo roguelike com interface textual. Realizado em JS para a disciplina de Programação de Jogos para Web, 2º semestre de 2016.

### Descrição

#### Objetivo

Vencer todos os inimigos dentro da dungeon.

#### Etapas de jogo

O jogador navega por um labirinto de salas que podem conter monstros e inimigos com força diferente. Quando encontra um inimigo o jogador tem a opção de enfrentá-lo em combate. 

Em combate o jogador age e reage, usando os poderes que tem e usando de concentração, ataque, esquiva e defesa para vencer seus adversários.

| Ações fora de combate | Ações em combate | Reações em combate |
| --- | --- | --- |
| Olhar, Mover | Atacar, Concentrar, Fugir, (poderes) | Defender, Esquivar, (poderes) |

Se vencer um inimigo o jogador absorve um poder novo e se cura, mas ao absorver um poder, perde os poderes mais fracos que já tinha.

Se a vida do jogador chegar em 0, ele morre e o jogo recomeça.
