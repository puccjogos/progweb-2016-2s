# Missile Command

Jogo simples, em que se deve destruir as bombas que caem do céu antes que elas destruam suas cidades e seu canhão. Se o canhão ou as duas cidades forem destruídos, o jogo acaba.

O jogo usa um objeto central, `MC`, que contém a lógica para o único estado (`Phaser.State`) do jogo. Nele, você encontra as funções que controlam os diferentes momentos do jogo (`preload`, `create`, `update` e `render`).

As outras classes controlam diferentes tipos de objetos no jogo: cidades, canhões e spawners de inimigos. As classes que tem uma representação visual (`City` e `Bullet`) extendem do tipo `Phaser.Sprite`, para se beneficiar das diversas funções já prontas assim como a integração direta com o fluxo da engine.

Em cada classe e método existe um link para onde do arquivo elas estão definidas. Dê uma olhada. :) A lógica do jogo está todo dentro de um único arquivo (`missilecommand.js`).